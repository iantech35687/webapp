
CREATE TABLE Manufacturers (
    ManufacturerId INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(100) NOT NULL
);

CREATE TABLE Cars (
    CarId INT PRIMARY KEY IDENTITY,
    Model NVARCHAR(100) NOT NULL,
    ManufacturerId INT NOT NULL,
    FOREIGN KEY (ManufacturerId) REFERENCES Manufacturers(ManufacturerId)
);

CREATE TABLE TopSpeeds (
    TopSpeedId INT PRIMARY KEY IDENTITY,
    Speed INT NOT NULL,
    CarId INT NOT NULL,
    FOREIGN KEY (CarId) REFERENCES Cars(CarId)
);
