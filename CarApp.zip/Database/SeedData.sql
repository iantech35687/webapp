
INSERT INTO Manufacturers (Name) VALUES ('Toyota');
INSERT INTO Manufacturers (Name) VALUES ('Ford');

INSERT INTO Cars (Model, ManufacturerId) VALUES ('Camry', 1);
INSERT INTO Cars (Model, ManufacturerId) VALUES ('RAV4', 1);
INSERT INTO Cars (Model, ManufacturerId) VALUES ('Mustang', 2);

INSERT INTO TopSpeeds (Speed, CarId) VALUES (200, 1);
INSERT INTO TopSpeeds (Speed, CarId) VALUES (180, 2);
INSERT INTO TopSpeeds (Speed, CarId) VALUES (250, 3);
