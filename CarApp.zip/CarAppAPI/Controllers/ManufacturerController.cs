
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CarAppAPI.Data;
using CarAppAPI.Models;

[Route("api/[controller]")]
[ApiController]
public class ManufacturerController : ControllerBase
{
    private readonly AppDbContext _context;

    public ManufacturerController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var manufacturers = await _context.Manufacturers
            .Include(m => m.Cars)
            .ThenInclude(c => c.TopSpeed)
            .ToListAsync();
        return Ok(manufacturers);
    }

    [HttpPost]
    public async Task<IActionResult> Add(Manufacturer manufacturer)
    {
        _context.Manufacturers.Add(manufacturer);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetAll), new { id = manufacturer.ManufacturerId }, manufacturer);
    }
}
