
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CarAppAPI.Data;
using CarAppAPI.Models;

[Route("api/[controller]")]
[ApiController]
public class CarController : ControllerBase
{
    private readonly AppDbContext _context;

    public CarController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var cars = await _context.Cars.Include(c => c.TopSpeed).ToListAsync();
        return Ok(cars);
    }

    [HttpPost]
    public async Task<IActionResult> Add(Car car)
    {
        _context.Cars.Add(car);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetAll), new { id = car.CarId }, car);
    }
}
