
using Microsoft.EntityFrameworkCore;
using CarAppAPI.Models;

namespace CarAppAPI.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Manufacturer> Manufacturers { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<TopSpeed> TopSpeeds { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}
