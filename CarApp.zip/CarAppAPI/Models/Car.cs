
public class Car
{
    public int CarId { get; set; }
    public string Model { get; set; }
    public int ManufacturerId { get; set; }
    public Manufacturer Manufacturer { get; set; }
    public TopSpeed TopSpeed { get; set; }
}
