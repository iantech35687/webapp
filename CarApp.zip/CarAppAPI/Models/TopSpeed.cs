
public class TopSpeed
{
    public int TopSpeedId { get; set; }
    public int Speed { get; set; }
    public int CarId { get; set; }
    public Car Car { get; set; }
}
